#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdatomic.h>
#include <string.h>

// Dynamic Array //
typedef struct {
	size_t used;
	size_t size;
	float *myArray;
} Array;

void initTheArray(Array *a, size_t initSize) {
	a->used = 0;
	a->size = initSize;
	a->myArray = malloc(initSize * sizeof(float));
}

void add2Array(Array *a, float element) {
	if (a->used == a->size) {
		a->size *= 2;
		a->myArray = realloc(a->myArray, a->size * sizeof(float));
	}
	a->myArray[a->used++] = element;
}

void freeTheArray(Array *a) {
	a->used = 0;
	a->size = 0;
	free(a->myArray);
	a->myArray = NULL;
}

// Structures //
typedef struct {
	char* inputfilepath;
	float alpha;
	float beta;
	int lockConfig;
	int globalCheckpoint;
	int threadIndex;
	Array *ArrayIn;
	Array *ArrayOut;
} inputDetails;

// Global Variables // 
inputDetails *allDetails;
int filesPerThread;
int buffer_size;
int numOfFiles;
int lock = 0;
Array outputChannelArray;
Array lockArray;
int klock = 0;

// Functions //
void wait(int* l)
{
    while((*l) < 0);
    (*l)--;
}

void signal(int* l)
{
    (*l)++;
}

void checkAlpha(float* a)
{
	if(a > 1 || a < 0)
	{
		a = 1;
	}
}

void checkBeta(float* b)
{
	if(b < 0)
	{
		b = 1;
	}
}

void checkEntry(float n)
{
	if(n < 0)
	{
		printf("Negative Entry Found: %.2f.\n", n);
		exit(0);
	}
}

int state = 0;

void checkRead(int thisThreadIndex) { // all threads must be in checkRead before they leave together!

	wait(&klock);
	if (++state != (numOfFiles/filesPerThread)) {
		signal(&klock);
		goto core;
	}
	signal(&klock);

	while (state != (numOfFiles/filesPerThread)){}	//make all threads group here

	core:
	wait(&klock);
	if (--state != 0) {
		signal(&klock);
		goto endofcheck;
	}
	signal(&klock);

	while (state != 0){};	//make all threads group here
	endofcheck:;
}

// 1 means myInput has a value
// 0 means NULL
int readBufferSize(char* myInput, FILE* fpr) {
	int i;
	int count = 0;
	int flag = 0;
	for(i = 0; i < buffer_size; i++) //cleaning input array for each iteration
		myInput[i] = NULL;

	for(i = 0; i < buffer_size; i++){  //i ensures buffer size is read and count is current index
		myInput[count] = fgetc(fpr);

		if(myInput[count] == '\n') //Handling the newline char
		{
			if((i+1) < buffer_size)
			{	
				i++;
				myInput[count] = fgetc(fpr);
				flag = 1;
			}
		}
		else if(myInput[count] == EOF && i == 1 && flag)
		{
			return 0;
		}
		else if(myInput[count] == EOF) //Handling end of file
		{
			myInput[count] = '\0';
			return 0;
		}
		else{
			flag = 0;
		}
		count++;
	}

	myInput[count] = '\0';
	return 1;
}

// Thread //
void *theThread(int thisThreadIndex) {

	char myInput[1024];

	if (allDetails[0].globalCheckpoint == 1) { // Global Checkpointing

		for (int i = 0 ; i < numOfFiles ; i++) {
			if ( allDetails[i].threadIndex != thisThreadIndex ){ continue; }

			FILE *fpr = fopen(allDetails[i]. inputfilepath, "r");
			if (fpr == NULL) {		
				printf("Unable to open input file: %s\n", allDetails[i].inputfilepath);
				return 0;
			}

			while (readBufferSize(myInput, fpr) && !feof(fpr)) {
				checkEntry(atof(myInput));
				add2Array(allDetails[i].ArrayIn, atof(myInput));
				checkRead(thisThreadIndex);
			} 
		}

	} else if (allDetails[0].globalCheckpoint == 0){ //Local Checkpointing

		FILE** filesArray = malloc(sizeof(FILE*)*filesPerThread);
		int fpCount = 0;

		for (int i = 0 ; i < numOfFiles ; i++) {
			if ( allDetails[i].threadIndex != thisThreadIndex ){ continue; }

			filesArray[fpCount] = fopen(allDetails[i]. inputfilepath, "r");
			if (filesArray[fpCount++] == NULL) {		
				printf("Unable to open input file: %s\n", allDetails[i].inputfilepath);
				return 0;
			}
		}

		int filesDone = 0;
		repeat:
			fpCount = 0;
			for (int i = 0 ; i < numOfFiles ; i++) {
				if ( allDetails[i].threadIndex != thisThreadIndex ){ continue; }

					if (readBufferSize(myInput, filesArray[fpCount]) && !feof(filesArray[fpCount])) {
						fpCount++;
						checkEntry(atof(myInput));
						add2Array(allDetails[i].ArrayIn, atof(myInput));
					} else {
						filesDone++;
					}

			} 
		if (filesDone != filesPerThread) {
			goto repeat;
		}

		for (int i = 0 ; i < filesPerThread ; i++) {
			fclose(filesArray[i]);
		}

		free(filesArray);
	} else {
		printf("global checkpointing value not recognised."); 
	}

	/* Alpha & Beta Calculation */
	for (int i = 0 ; i < numOfFiles ; i++) {


		if ( allDetails[i].threadIndex != thisThreadIndex ){
			continue;
		}

		float tempFloat;
		for (int j = 0 ; j < allDetails[i].ArrayIn->used ; j++) {

			if ( j > 0 ) {
				tempFloat = (float)(allDetails[i].alpha * allDetails[i].ArrayIn->myArray[j] + (1 - allDetails[i].alpha) * allDetails[i].ArrayOut->myArray[j-1]);
			} else {
				tempFloat = allDetails[i].ArrayIn->myArray[j];
			}

			add2Array(allDetails[i].ArrayOut, tempFloat);
		}

		for (int j = 0 ; j < allDetails[i].ArrayIn->used ; j++) {
			allDetails[i].ArrayOut->myArray[j] = (float)(allDetails[i].beta * allDetails[i].ArrayOut->myArray[j]);
		}
	}

	/* Locks and output to final channel */
	for (int i = 0 ; i < numOfFiles ; i++) {

		if (allDetails[i].threadIndex != thisThreadIndex){
			continue;
		}	
		
		if(allDetails[i].ArrayOut->used > outputChannelArray.used)
		{
			for(int j = outputChannelArray.used; j < allDetails[i].ArrayOut->used; j++)
			{
				add2Array(&outputChannelArray, 0);  //adding initial values
				add2Array(&lockArray, 0);
			}
		}

		if(allDetails[i].lockConfig == 1)
		{
			//If lock_config = 1, a single global lock should be used for accessing the output channel
			wait(&lock);
			for(int j = 0; j < allDetails[i].ArrayOut->used; j++)
				outputChannelArray.myArray[j]  = outputChannelArray.myArray[j]+ allDetails[i].ArrayOut->myArray[j];  //adding initial values
			signal(&lock);  
		}
		else if(allDetails[i].lockConfig == 2)
		{
			//If lock_config = 2, use a different lock for each entry in the output channel
			for(int j = 0; j < allDetails[i].ArrayOut->used; j++)
			{
				wait(&lockArray.myArray[j]);
				outputChannelArray.myArray[j]  = outputChannelArray.myArray[j]+ allDetails[i].ArrayOut->myArray[j];  //adding initial values
				signal(&lockArray.myArray[j]);
			}
		}
		else if(allDetails[i].lockConfig == 3)
		{
			//If lock_config = 3, use compare_and_swap to update the entries in the output channel
			int zero = 0;
			while(atomic_compare_exchange_strong(&lock, &zero, 1) != 0);
			for(int j = 0; j < outputChannelArray.used; j++)
				outputChannelArray.myArray[j]  = outputChannelArray.myArray[j]+ allDetails[i].ArrayOut->myArray[j];  //adding initial values
			lock = 0;
		}
		else
			printf("lock configuration not recognised."); 
	}

}

int main(int argc, char* argv[]) {

	/* Arguments */
	buffer_size = atoi(argv[1]);
	int num_threads = atoi(argv[2]);
	char* metadata_file_path = argv[3];
	int lock_config = atoi(argv[4]);
	int global_checkpointing = atoi(argv[5]);
	char *output_file_path = argv[6];

	/* Initialization */
	initTheArray(&outputChannelArray,3);
	initTheArray(&lockArray, 3);
	char myInput[1024];
	inputDetails myInputDetails;
	char* inputfilepath;
	float alpha;
	float beta; 

	/* Read Metadata */
	FILE *fp = fopen(metadata_file_path, "r");
	if (fp == NULL) {
		printf("Unable to open metadata file: %s\n", metadata_file_path);
		return 0;
	}

	//to read numOfFiles
	if (!fgets(myInput, 1024, fp) || feof(fp) || ferror(fp) ) {
		printf("Unable to read metadata file: %s\n", metadata_file_path);
		return 0;
	}
	numOfFiles = atoi(myInput);
	allDetails = malloc(sizeof(inputDetails) * numOfFiles);
	filesPerThread = numOfFiles/num_threads;

	int i = 0;
    while(i < (filesPerThread)) {

		for(int j = 0 ; j < num_threads ; j++) {

			// mallocs
			allDetails[i*num_threads + j].inputfilepath = malloc(1024);
			allDetails[i*num_threads + j].ArrayIn = malloc( sizeof(Array) );
			allDetails[i*num_threads + j].ArrayOut = malloc( sizeof(Array) );


			if (!fgets(myInput, 1024, fp) || ferror(fp) ) {
				printf("Unable to read metadata file\n");
				return 0;
			} strtok(myInput, "\n");
			strcpy(allDetails[i*num_threads + j].inputfilepath, myInput);


			if (!fgets(myInput, 1024, fp) || ferror(fp) ) {
				printf("Unable to read metadata file\n");
				return 0;
			} strtok(myInput, "\n");

			allDetails[i*num_threads + j].alpha = atof(myInput);
			checkAlpha(&allDetails[i*num_threads + j].alpha);


			if (!fgets(myInput, 1024, fp) || ferror(fp) ) {
				printf("Unable to read metadata file\n");
				return 0;
			} strtok(myInput, "\n");

			allDetails[i*num_threads + j].beta = atof(myInput);
			checkBeta(&allDetails[i*num_threads + j].beta);

			allDetails[i*num_threads + j].lockConfig = lock_config;
			allDetails[i*num_threads + j].globalCheckpoint = global_checkpointing;
			allDetails[i*num_threads + j].threadIndex = j;

			// Any details you want to double check
			// printf("filenumber: %d thread index: %d path: %s\n", i*num_threads + j, allDetails[i*num_threads + j].threadIndex, allDetails[i*num_threads + j].inputfilepath);

			initTheArray(allDetails[i*num_threads + j].ArrayIn, 3);
    		initTheArray(allDetails[i*num_threads + j].ArrayOut, 3);
					
		}

		i++;
	}

	// Initializations //
	pthread_t * threadIDs = malloc(sizeof(pthread_t) * num_threads);

	for(int j = 0 ; j < num_threads ; j++) {
		pthread_create(&threadIDs[j], NULL, theThread, j);
	}
	for(int j = 0 ; j < num_threads ; j++) {
		pthread_join(threadIDs[j], NULL);
	}

	/* Output */
	FILE* fptr2;
    fptr2 = fopen(output_file_path, "w");
    if (fptr2 == NULL) 
    {
        printf("Unable to open file: %s\n", output_file_path);
        return 0;
    }   
    for(int i = 0; i < outputChannelArray.used; i++)
    {
		if(outputChannelArray.myArray[i] > 65536)
			outputChannelArray.myArray[i] = 65536;
		if(outputChannelArray.myArray[i] > (int)outputChannelArray.myArray[i])
			outputChannelArray.myArray[i] = (int)outputChannelArray.myArray[i] + 1;
	    fprintf(fptr2, "%.0f", outputChannelArray.myArray[i]);
		if (i != outputChannelArray.used - 1)
	 		fprintf(fptr2,"\n");
	}
    close(fptr2);

	// Freeing Any Used Memory
	for (int i = 0 ; i < numOfFiles ; i++) {
		free(allDetails[i].inputfilepath);
		freeTheArray(allDetails[i].ArrayIn);
		freeTheArray(allDetails[i].ArrayOut);
	}
	free(threadIDs);

    return 0;
}