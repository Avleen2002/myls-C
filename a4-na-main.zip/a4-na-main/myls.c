#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <dirent.h>
#include <sys/stat.h>
#include <stdint.h>
#include <time.h>
#include <grp.h>
#include <pwd.h>

// GLOBAL VAR----------------------------------------------------//
struct dirent **fileList; 
int numOfFiles;

int count = 0; 


// DYNAMIC ARRAY----------------------------------------------------//
typedef struct {
	size_t used;
	size_t size;
	char **myArray;
} Array;

void initTheArray(Array *a, size_t initSize) {
	a->used = 0;
	a->size = initSize;
	a->myArray = malloc(initSize * sizeof(char*));
}

void add2Array(Array *a, char* element) {
	if (a->used == a->size) {
		a->size *= 2;
		a->myArray = realloc(a->myArray, a->size * sizeof(char*));
	}
	a->myArray[a->used++] = element;
}

void freeTheArray(Array *a) {
	a->used = 0;
	a->size = 0;
	free(a->myArray);
	a->myArray = NULL;
}

// FUNCTIONS-----------------------------------------------------//
void deleteHidden(struct dirent **fileArray, int* n);
void freeFileArray(struct dirent **fileArray, int n);
int is_dir(const char* fileName, const char* filePath); 
void recursionFunction(char* dir, int L, int I, int R, char* filePath); 
void printFile(char *fileName, int L, int I);
void printMain(struct dirent **fileArray, int size, int L, int I, int R, char* filePath);  
void print_name_or_link(const char* filename);
void display_long(char* filename);
void whichOption(int *R, int *L, int *I, char someChar);
int checkIfCharExists(char *str, char value);
char *strremove(char *str, const char *sub);  
void printRL(char* filename, char* filePath);  

// INT MAIN------------------------------------------------------//
int main(int argc,char** argv) {

	// Initializations
	Array dirArr;
	initTheArray(&dirArr, argc);
	int flagArgs = 0;
	int R = 0;
	int L = 0;
	int I = 0;

	if(argc < 1) {
		exit(EXIT_FAILURE); 
	}

	for (int arg = 1 ; arg < argc ; arg++) {
		if(argv[arg][0] == '-' && flagArgs == 0) {
			int len = strlen(argv[arg]);
			if (len >= 2) {
				whichOption(&R, &L, &I, argv[arg][1]);
				if (len >= 3) {
					whichOption(&R, &L, &I, argv[arg][2]);
					if (len >= 4) {
						whichOption(&R, &L, &I, argv[arg][3]);
					}
				}
			}
		} else {
			flagArgs = 1;
			add2Array(&dirArr, argv[arg]);
		}
	}

	char* filePath = malloc(sizeof(char)* 1024);
	strcpy(filePath, "");

	if (flagArgs) {			
		//External Dir
		for (int i = 0 ; i < dirArr.used ; i++) {
			if (!is_dir(dirArr.myArray[i], filePath)) {
				printFile(dirArr.myArray[i], L, I);				//For Files

				//LI cases
				// if (R == 0 && I == 1 && L == 1 && i != dirArr.used - 1) {
				// 	printf("\n");
				// }

			} else {											//For Dir
				if (R) {
					recursionFunction(dirArr.myArray[i], L, I, R, filePath);
				} else {

					// Inserts a '/' if it does not exist
					if(dirArr.myArray[i][strlen(dirArr.myArray[i]) - 1] != '/')
						printf("%s/:\n", dirArr.myArray[i]);
					else
						printf("%s:\n", dirArr.myArray[i]);

					// Make File Path
					numOfFiles = scandir(dirArr.myArray[i], &fileList, NULL, alphasort);
					if(numOfFiles < 0) {
						perror("scandir didnt scan any files!"); 
						exit(EXIT_FAILURE); 
					}
					deleteHidden(fileList, &numOfFiles);

					//LI cases
					if ((R == 0 && I == 1 && L == 1)|| L == 1) {
						
						strcat(filePath, dirArr.myArray[i]);
						if(filePath[strlen(filePath) - 1] != '/')
							strcat(filePath, "/");
						
						printMain(fileList, numOfFiles, L, I, R, filePath);

						char* str = malloc(sizeof(char)* 1024);
						strcpy(str, dirArr.myArray[i]);

						if(dirArr.myArray[i][strlen(dirArr.myArray[i]) - 1] != '/')
							strcat(str, "/"); 

						strremove(filePath, str);
						free(str);

						if (i != dirArr.used - 1) {
							printf("\n");
						}
						
					} else {
						printMain(fileList, numOfFiles, L, I, R, filePath);
						//I case
						if(R == 0 && I == 1 && L ==0 && i != dirArr.used - 1) {
							printf("\n");
						}
					}
					freeFileArray(fileList, numOfFiles);
				}
			}
		}
	} else {
		//Current Dir
		if (R) {
			recursionFunction(".", L, I, R, filePath);  
		} else {
			printf(".\n");
			numOfFiles = scandir(".", &fileList, NULL, alphasort);
			if(numOfFiles < 0) {
				perror("scandir didnt scan any files!");
				exit(EXIT_FAILURE); 
			}
			deleteHidden(fileList, &numOfFiles);
			printMain(fileList, numOfFiles, L, I, R, filePath);
			freeFileArray(fileList, numOfFiles);
		}
	}

	if (argc >= 2) {
		freeTheArray(&dirArr);
	}

	free(filePath);
	exit(EXIT_SUCCESS); 
} 


void deleteHidden(struct dirent **fileArray, int* n) 
{
	// hiddenFileCount hidden
	int hiddenFileCount = 0;
	for (int i = 0 ; i < *n ; i++) {
    	if (fileArray[i]->d_name[0] == '.') {
			hiddenFileCount++;
    	}
		else{
			break;
		}	
	}
	
	// move hiddenFileCount blocks left
	for (int i = 0 ; i < *n - hiddenFileCount; i++) {
		if(i < hiddenFileCount) // deleting overwritten elements
			free(fileArray[i]);
		fileArray[i] = fileArray[i + hiddenFileCount];
	}
	
	// Updating numOfFiles
	*n = *n - hiddenFileCount;
}

void freeFileArray(struct dirent **fileArray, int n)
{
	for (int i = 0 ; i < n; i++) {
		free(fileArray[i]);
	}
	
	free(fileArray); 
}

int is_dir(const char* fileName, const char* filePath) 
{
	char* temp = malloc(sizeof(char)*1024);
	strcpy(temp,"");

	if(strcmp(filePath, "")){
		strcpy(temp, filePath);
		strcat(temp, "/");
	}

	strcat(temp, fileName);
	
    struct stat sb;
	if (lstat(temp, &sb) < 0)
    {
        perror("Error reading directory: ");
        exit(EXIT_FAILURE);
    }
 
    return (sb.st_mode & S_IFDIR) ? 1 : 0;
}

void recursionFunction(char* dir, int L, int I, int R, char* filePath) 
{

	if(is_dir(dir, filePath) == 1)
	{
		struct dirent **dirFiles; 
		int numFiles = 0;

		
		// updating filePath
		if(dir[0] != '.')
		{ 
			// shouldn't append anything for curr dir
			strcat(filePath, dir);
			if(filePath[strlen(filePath) - 1] != '/')
				strcat(filePath, "/");
			
			// scandir somedir
			numFiles = scandir(filePath, &dirFiles, NULL, alphasort); 
		}
		else{
			// scandir current
			numFiles = scandir(dir, &dirFiles, NULL, alphasort); 
		}		

		// deleting Hidden files including dir
		deleteHidden(dirFiles, &numFiles);	

		if(count++ > 0)
			printf("\n");

		if(strcmp(dir, "."))	//other dir
		{
			printf("%s:\n",filePath); 
		}
		else					//curr dir
		{
			printf(".\n",dir); //might be wrog for solo guys :testing
		}

		// calling print
		printMain(dirFiles, numFiles, L, I, R, filePath);
		
		// Recursive step
		for (int i = 0 ; i < numFiles ; i++)
		{
			if(is_dir(dirFiles[i]->d_name, filePath) == 1)
				recursionFunction(dirFiles[i]->d_name, L, I, R, filePath);
		}
		
		// FREE FUNCTION
		freeFileArray(dirFiles, numFiles);

		// Bringing filePath back to original
		char* str = malloc(sizeof(char)* 1024);
		strcpy(str, dir);

		if(dir[strlen(dir) - 1] != '/')
			strcat(str, "/"); 

		strremove(filePath, str);
		free(str);
	}
	else{
		// Not a directory but it is a file!
		printFile(dir, L, I);
	}
}

void printFile(char *fileName, int L, int I)
{
	if(I == 1) // if i option is selected
	{
		struct stat sb;
		if (lstat(fileName, &sb) < 0)
		{   
			perror("Display Error");
			exit(EXIT_FAILURE);
		}
		printf("%ld\t", sb.st_ino);
	}

	if(L == 1) // if l option is selected
	{
		display_long(fileName);
	}
	else
	{
		printf("%s", fileName); 
		printf("\n");
	}
}

void printMain(struct dirent **fileArray, int size, int L, int I, int R, char* filePath)
{
	for (int i = 0 ; i < size ; i++)
	{
		if(I == 1) // if -i option is selected
		{
			printf("%ld\t", fileArray[i]->d_ino);
		}
		if(R == 0 && L == 1 && I == 0) {
			printRL(fileArray[i]->d_name, filePath);
		}
		else if(R == 0 && L == 1 && I == 1) {
			printRL(fileArray[i]->d_name, filePath);
		}
		else if(L == 1 && R == 1) // if -Rl option is selected
		{
			printRL(fileArray[i]->d_name, filePath);
		}
		else if(L == 1) // if -l option is selected
		{
			display_long(fileArray[i]->d_name);
		}
		else
		{
			printf("%s",fileArray[i]->d_name); 
			printf("\n");
		}
	}
}

void print_name_or_link(const char* filename)  
{
    if (S_IFLNK)
    {
        char link_buf[512];
        int count = readlink(filename, link_buf, sizeof(link_buf));
 
        if (count >= 0)
        {
            link_buf[count] = '\0';
			printf(" %s -> %s\n", filename, link_buf);
 
            return;
        }
		else
		{
			printf(" %s\n", filename);
		}
    }
}
 
void display_long(char* filename) 
{
	// printf("%s\n", filename);

    struct stat sb;
	if (lstat(filename, &sb) < 0)
    {   
        perror("Display Long Error");
        exit(EXIT_FAILURE);
    }
 
	printf( (S_ISDIR(sb.st_mode)) ? "d" : "-");
	printf( (sb.st_mode & S_IRUSR) ? "r" : "-");
	printf( (sb.st_mode & S_IWUSR) ? "w" : "-");
	printf( (sb.st_mode & S_IXUSR) ? "x" : "-");
	printf( (sb.st_mode & S_IRGRP) ? "r" : "-");
	printf( (sb.st_mode & S_IWGRP) ? "w" : "-");
	printf( (sb.st_mode & S_IXGRP) ? "x" : "-");
	printf( (sb.st_mode & S_IROTH) ? "r" : "-");
	printf( (sb.st_mode & S_IWOTH) ? "w" : "-");
	printf( (sb.st_mode & S_IXOTH) ? "x" : "-");
	printf("\t");

    printf("%ld\t", sb.st_nlink);

	char * uId = getpwuid(sb.st_uid)->pw_name;
    printf("%s\t", uId);
    printf("%s\t", getgrgid(sb.st_gid)->gr_name);


	printf("\t%jd", (intmax_t) sb.st_size);

	char* details = ctime(&sb.st_mtime);
	char* date = malloc(6);
	char* year = &details[strlen(details) - 1 - 4];
	year[strlen(year)-1] = '\0';
	char* time = malloc(5);

	for (int i = 4 ; i < (4 + 6) ; i++) {
		date[i-4] = details[i];
	}
	for (int i = 11 ; i < (11 + 6) ; i++) {
		time[i-11] = details[i];
	}
	time[5] = '\0';

	printf("\t%s %s %s\t", date, year, time);

	free(date);
	free(time);
    
    print_name_or_link(filename);
}

void whichOption(int *R, int *L, int *I, char someChar) {

	if (someChar == 'R') {
		*R = 1;
	} else if (someChar == 'l') {
		*L = 1;
	} else if (someChar == 'i') {
		*I = 1;
	} else {
		printf("Error: Unsupported Option\n");
		exit(EXIT_FAILURE);
	}
}

int checkIfCharExists(char *str, char value) {
	int i = 0;
	while (str[i] != '\0') {
		if (str[i] == value) {
			return 1;
		}
		i++;
	}
	return 0;
}

void printRL(char* fileName, char* filePath) 
{
	char* temp = malloc(sizeof(char)*1024);
	strcpy(temp,"");

	if(strcmp(filePath, "")){
		strcpy(temp, filePath);
		strcat(temp, "/");
	}

	strcat(temp, fileName);
	
    struct stat sb;
	if (lstat(temp, &sb) < 0)
    {   
        perror("Display Error: ");
        exit(EXIT_FAILURE);
    }
 
	printf( (S_ISDIR(sb.st_mode)) ? "d" : "-");
	printf( (sb.st_mode & S_IRUSR) ? "r" : "-");
	printf( (sb.st_mode & S_IWUSR) ? "w" : "-");
	printf( (sb.st_mode & S_IXUSR) ? "x" : "-");
	printf( (sb.st_mode & S_IRGRP) ? "r" : "-");
	printf( (sb.st_mode & S_IWGRP) ? "w" : "-");
	printf( (sb.st_mode & S_IXGRP) ? "x" : "-");
	printf( (sb.st_mode & S_IROTH) ? "r" : "-");
	printf( (sb.st_mode & S_IWOTH) ? "w" : "-");
	printf( (sb.st_mode & S_IXOTH) ? "x" : "-");
	printf("\t");

    printf("%ld\t", sb.st_nlink);

	char * uId = getpwuid(sb.st_uid)->pw_name;
    printf("%s\t", uId);
    printf("%s\t", getgrgid(sb.st_gid)->gr_name);


	printf("\t%jd", (intmax_t) sb.st_size);

	char* details = ctime(&sb.st_mtime);
	char* date = malloc(6);
	char* year = &details[strlen(details) - 1 - 4];
	year[strlen(year)-1] = '\0';
	char* time = malloc(5);

	for (int i = 4 ; i < (4 + 6) ; i++) {
		date[i-4] = details[i];
	}
	for (int i = 11 ; i < (11 + 6) ; i++) {
		time[i-11] = details[i];
	}
	time[5] = '\0';

	printf("\t%s %s %s\t", date, year, time); 
    print_name_or_link(fileName);

	free(date);
	free(time);
	free(temp);
}


char *strremove(char *str, const char *sub) {
    char *p, *q, *r;
    if (*sub && (q = r = strstr(str, sub)) != NULL) {
        size_t len = strlen(sub);
        while ((r = strstr(p = r + len, sub)) != NULL) {
            memmove(q, p, r - p);
            q += r - p;
        }
        memmove(q, p, strlen(p) + 1);
    }
    return str;
}